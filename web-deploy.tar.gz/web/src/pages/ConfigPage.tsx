import { useEffect, useState } from 'react'
import { Save, Settings, Globe, Clock, CalendarDays, Zap } from 'lucide-react'
import Layout from '../components/Layout'
import PageHeader from '../components/PageHeader'
import LoadingSpinner from '../components/LoadingSpinner'
import { getParametres, updateParametres } from '../api/parametreApi'
import type { ParametreGlobalRequestDto } from '../types'

/**
 * Configuration — paramètres globaux (Phase 8).
 * Reproduit config_page.dart (mobile) : sections "Général" & "Coût de fuite".
 */
export default function ConfigPage() {
  const [form, setForm] = useState<ParametreGlobalRequestDto>({})
  // Valeur brute (string) du champ décimal pour éviter NaN pendant la saisie.
  const [coutKwhRaw, setCoutKwhRaw] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null)

  useEffect(() => {
    const load = async () => {
      try {
        const data = await getParametres()
        setForm({
          devise: data.devise,
          coutVapeurParTonne: data.coutVapeurParTonne,
          heuresFonctionnementAnnuelles: data.heuresFonctionnementAnnuelles,
          facteurEmissionCO2: data.facteurEmissionCO2,
          langue: data.langue,
          heuresActiviteParJour: data.heuresActiviteParJour,
          joursActiviteParAn: data.joursActiviteParAn,
          coutKwhDiram: data.coutKwhDiram,
        })
        setCoutKwhRaw(data.coutKwhDiram != null ? String(data.coutKwhDiram) : '')
      } catch (err) {
        console.error('Erreur chargement paramètres:', err)
        setMessage({ type: 'err', text: 'Impossible de charger les paramètres.' })
      } finally {
        setLoading(false)
      }
    }
    void load()
  }, [])

  const set = (key: keyof ParametreGlobalRequestDto, value: unknown) =>
    setForm((f) => ({ ...f, [key]: value }))

  const handleSave = async () => {
    setSaving(true)
    setMessage(null)
    try {
      // Convertir la valeur brute du champ décimal en nombre avant envoi.
      const payload: ParametreGlobalRequestDto = {
        ...form,
        coutKwhDiram: coutKwhRaw === '' ? undefined : Number(coutKwhRaw.replace(',', '.')),
      }
      await updateParametres(payload)
      setMessage({ type: 'ok', text: 'Configuration sauvegardée ✓' })
    } catch (err) {
      console.error('Erreur enregistrement:', err)
      setMessage({ type: 'err', text: "Erreur lors de l'enregistrement." })
    } finally {
      setSaving(false)
    }
  }

  const sectionHeader = (icon: React.ReactNode, title: string) => (
    <div className="flex items-center gap-2.5">
      <span className="w-1 h-5 rounded bg-[#00875a]" />
      <span className="text-lg font-bold text-[#111111]">{title}</span>
      {icon}
    </div>
  )

  const field = (
    label: string,
    key: keyof ParametreGlobalRequestDto,
    type: 'text' | 'number' = 'text',
    icon?: React.ReactNode,
    suffix?: string,
    decimal = false,
  ) => (
    <label className="flex flex-col gap-1.5">
      <span className="text-sm font-bold text-[#111111]">{label}</span>
      <div className="relative">
        {icon && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#00875a]">
            {icon}
          </span>
        )}
        <input
          type={decimal ? 'text' : type}
          inputMode={decimal ? 'decimal' : undefined}
          value={decimal ? coutKwhRaw : (form[key] ?? '')}
          onChange={(e) => {
            if (decimal) {
              setCoutKwhRaw(e.target.value)
              return
            }
            if (type !== 'number') {
              set(key, e.target.value)
              return
            }
            const raw = e.target.value.replace(',', '.')
            set(key, raw === '' ? undefined : Number(raw))
          }}
          className={`w-full px-3 py-2.5 border border-[#e5e7eb] rounded-xl text-sm bg-[#fafafa] focus:outline-none focus:ring-2 focus:ring-[#00875a]/30 focus:border-[#00875a] focus:bg-white ${
            icon ? 'pl-10' : ''
          }`}
        />
        {suffix && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#6b7280]">
            {suffix}
          </span>
        )}
      </div>
    </label>
  )

  return (
    <Layout>
      <div className="p-6 max-w-3xl mx-auto">
        <PageHeader
          title="Configuration OCP"
          subtitle="Paramètres de calcul du coût des fuites"
        />

        {loading ? (
          <LoadingSpinner />
        ) : (
          <div className="bg-white border border-[#e5e7eb] rounded-2xl p-6 space-y-8">
            {/* ── Section : Général ── */}
            <div className="space-y-4">
              {sectionHeader(<Globe size={16} className="text-[#00875a]" />, 'Général')}

              {/* Langue */}
              <label className="flex flex-col gap-1.5">
                <span className="text-sm font-bold text-[#111111]">Langue de l'application</span>
                <div className="relative">
                  <Globe size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#00875a]" />
                  <select
                    value={form.langue ?? 'fr'}
                    onChange={(e) => set('langue', e.target.value)}
                    className="w-full px-3 py-2.5 pl-10 border border-[#e5e7eb] rounded-xl text-sm bg-[#fafafa] focus:outline-none focus:ring-2 focus:ring-[#00875a]/30 focus:border-[#00875a] focus:bg-white"
                  >
                    <option value="fr">Français</option>
                    <option value="en">English</option>
                    <option value="ar">العربية</option>
                  </select>
                </div>
              </label>

              {field('Heures d\'activité par jour', 'heuresActiviteParJour', 'number', <Clock size={16} />)}
              {field('Jours d\'activité par an', 'joursActiviteParAn', 'number', <CalendarDays size={16} />)}
            </div>

            {/* ── Section : Coût de fuite ── */}
            <div className="space-y-4">
              {sectionHeader(<Settings size={16} className="text-[#00875a]" />, 'Coût de fuite')}

              {field('Coût par kWh (en Diram)', 'coutKwhDiram', 'number', <Zap size={16} />, 'MAD/kWh', true)}
              {field('Coût vapeur par tonne (DH)', 'coutVapeurParTonne', 'number', undefined, 'DH/tonne')}
              {field('Heures de fonctionnement annuelles', 'heuresFonctionnementAnnuelles', 'number', undefined, 'h/an')}
              {field('Facteur émission CO₂', 'facteurEmissionCO2', 'number')}
              {field('Devise', 'devise')}
            </div>

            {message && (
              <p className={`text-sm ${message.type === 'ok' ? 'text-[#00875a]' : 'text-red-600'}`}>
                {message.text}
              </p>
            )}

            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-[#00875a] text-white text-sm font-bold hover:bg-[#007049] transition-colors disabled:opacity-60"
            >
              <Save size={16} />
              {saving ? 'Enregistrement…' : 'Sauvegarder'}
            </button>
          </div>
        )}
      </div>
    </Layout>
  )
}

